# OBY Fashion Store

Starter website ya duka la nguo kwa HTML, CSS na JavaScript ya kawaida.

## Structure

```text
oby-fashion-store/
├── index.html
├── style.css
├── script.js
├── README.md
└── assets/
    └── images/
```

## Kuendesha locally
Fungua `index.html` kwenye browser, au tumia VS Code Live Server.

## Kuweka bidhaa zako
Fungua `script.js`, kisha badilisha list ya `PRODUCTS`:
- `name`: jina la bidhaa
- `category`: `Fashion`, `T-Shirt`, `Shoes`, au `Accessories`
- `price`: bei kwa TSh bila comma
- `emoji`: icon ya muda kama huna picha
- `image`: weka njia ya picha, mfano `assets/images/tshirt.jpg`

## Kuunganisha WhatsApp
Ndani ya `script.js`, badilisha:
`const WHATSAPP_NUMBER = "2557XXXXXXXX";`
Weka namba yako halisi ya Tanzania kwa format ya kimataifa bila `+`, nafasi, au alama nyingine, mfano `2557XXXXXXXX`.

## Deploy kwenye Render
1. Push folder hii kwenye GitHub repository.
2. Render → New → **Static Site** → chagua repository.
3. Build Command: acha wazi.
4. Publish Directory: `.`
5. Bonyeza Deploy.

Hii ni frontend starter tu. Kikapu kinafanya kazi ndani ya browser na oda zinaandaliwa kwa WhatsApp. Hakuna database, akaunti za wateja, online payments, au dashboard ya kusimamia bidhaa bado.
