/*
  OBY FASHION STORE
  1) Badilisha WHATSAPP_NUMBER iwe namba yako ya biashara, kwa format ya kimataifa bila +.
     Mfano Tanzania: 2557XXXXXXXX
  2) Badilisha bidhaa, bei na picha ndani ya PRODUCTS hapa chini.
*/
const WHATSAPP_NUMBER = "2557XXXXXXXX";

const PRODUCTS = [
  { id: 1, name: "Classic Streetwear", category: "Fashion", price: 35000, emoji: "🧥", badge: "POPULAR", image: "" },
  { id: 2, name: "Premium T-Shirt", category: "T-Shirt", price: 18000, emoji: "👕", badge: "NEW", image: "" },
  { id: 3, name: "Urban Sneakers", category: "Shoes", price: 55000, emoji: "👟", badge: "", image: "" },
  { id: 4, name: "Classic Cap", category: "Accessories", price: 12000, emoji: "🧢", badge: "", image: "" },
  { id: 5, name: "Casual Outfit", category: "Fashion", price: 42000, emoji: "👔", badge: "", image: "" },
  { id: 6, name: "Oversized Tee", category: "T-Shirt", price: 22000, emoji: "👕", badge: "TRENDING", image: "" },
  { id: 7, name: "Everyday Trainers", category: "Shoes", price: 48000, emoji: "👟", badge: "", image: "" },
  { id: 8, name: "Style Watch", category: "Accessories", price: 28000, emoji: "⌚", badge: "", image: "" }
];

const state = { category: "All", search: "", cart: {} };
const money = amount => new Intl.NumberFormat("en-TZ", { maximumFractionDigits: 0 }).format(amount);
const byId = id => document.getElementById(id);
const productGrid = byId("productGrid");
const emptyState = byId("emptyState");

function renderProducts() {
  const filtered = PRODUCTS.filter(product => {
    const categoryMatch = state.category === "All" || product.category === state.category;
    const searchMatch = `${product.name} ${product.category}`.toLowerCase().includes(state.search.toLowerCase());
    return categoryMatch && searchMatch;
  });
  productGrid.innerHTML = filtered.map(product => `
    <article class="product-card">
      <div class="product-image">
        ${product.image ? `<img src="${escapeAttribute(product.image)}" alt="${escapeAttribute(product.name)}" loading="lazy">` : `<span class="placeholder" aria-hidden="true">${product.emoji}</span>`}
        ${product.badge ? `<span class="product-badge">${escapeHTML(product.badge)}</span>` : ""}
      </div>
      <div class="product-info">
        <p class="product-category">${escapeHTML(product.category)}</p>
        <h3 class="product-name">${escapeHTML(product.name)}</h3>
        <div class="product-bottom">
          <span class="product-price">TSh ${money(product.price)}</span>
          <button class="add-button" type="button" data-add="${product.id}" aria-label="Ongeza ${escapeAttribute(product.name)} kwenye kikapu">+</button>
        </div>
      </div>
    </article>`).join("");
  emptyState.hidden = filtered.length !== 0;
}

function renderCart() {
  const entries = Object.entries(state.cart).filter(([, qty]) => qty > 0);
  const count = entries.reduce((sum, [, qty]) => sum + qty, 0);
  const total = entries.reduce((sum, [id, qty]) => {
    const product = PRODUCTS.find(item => item.id === Number(id));
    return sum + (product ? product.price * qty : 0);
  }, 0);
  byId("cartCount").textContent = count;
  byId("cartTotal").textContent = `TSh ${money(total)}`;

  if (!entries.length) {
    byId("cartItems").innerHTML = '<p class="muted">Bado hujaongeza bidhaa.</p>';
    return;
  }

  byId("cartItems").innerHTML = entries.map(([id, qty]) => {
    const product = PRODUCTS.find(item => item.id === Number(id));
    if (!product) return "";
    return `<div class="cart-row">
      <div class="cart-product"><span class="cart-thumb">${product.emoji}</span><div><strong>${escapeHTML(product.name)}</strong><small>TSh ${money(product.price)} kila moja</small></div></div>
      <div class="quantity-controls">
        <button type="button" data-change="${product.id}" data-delta="-1" aria-label="Punguza ${escapeAttribute(product.name)}">−</button>
        <span>${qty}</span>
        <button type="button" data-change="${product.id}" data-delta="1" aria-label="Ongeza ${escapeAttribute(product.name)}">+</button>
      </div>
    </div>`;
  }).join("");
}

function addToCart(id) {
  state.cart[id] = (state.cart[id] || 0) + 1;
  renderCart();
  showToast("Bidhaa imeongezwa kwenye kikapu.");
}
function changeQuantity(id, delta) {
  state.cart[id] = (state.cart[id] || 0) + delta;
  if (state.cart[id] <= 0) delete state.cart[id];
  renderCart();
}
function checkout() {
  const entries = Object.entries(state.cart).filter(([, qty]) => qty > 0);
  if (!entries.length) return showToast("Tafadhali ongeza bidhaa kwenye kikapu kwanza.");
  if (!/^255\d{9}$/.test(WHATSAPP_NUMBER)) {
    return showToast("Weka namba yako ya WhatsApp ndani ya script.js kabla ya kupokea oda.");
  }
  let total = 0;
  const lines = entries.map(([id, qty]) => {
    const product = PRODUCTS.find(item => item.id === Number(id));
    const subtotal = product.price * qty;
    total += subtotal;
    return `• ${product.name} x${qty} — TSh ${money(subtotal)}`;
  });
  const message = `Habari OBY Fashion Store, naomba kuagiza:\n\n${lines.join("\n")}\n\nJumla: TSh ${money(total)}\n\nJina langu:\nMahali nilipo:`;
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
}

function showToast(message) {
  const toast = byId("toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 2800);
}
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]));
}
function escapeAttribute(value) { return escapeHTML(value); }

byId("categories").addEventListener("click", event => {
  const button = event.target.closest("[data-category]");
  if (!button) return;
  state.category = button.dataset.category;
  document.querySelectorAll(".category").forEach(item => item.classList.toggle("active", item === button));
  renderProducts();
});
byId("searchInput").addEventListener("input", event => {
  state.search = event.target.value.trim();
  renderProducts();
});
productGrid.addEventListener("click", event => {
  const button = event.target.closest("[data-add]");
  if (button) addToCart(Number(button.dataset.add));
});
byId("cartItems").addEventListener("click", event => {
  const button = event.target.closest("[data-change]");
  if (button) changeQuantity(Number(button.dataset.change), Number(button.dataset.delta));
});
byId("checkoutButton").addEventListener("click", checkout);
byId("cartJump").addEventListener("click", () => byId("cart").scrollIntoView({ behavior: "smooth" }));
byId("year").textContent = new Date().getFullYear();

renderProducts();
renderCart();
