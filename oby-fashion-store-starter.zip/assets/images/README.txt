Weka picha zako za bidhaa hapa. Mfano: tshirt.jpg, shoes.jpg, fashion.jpg.
